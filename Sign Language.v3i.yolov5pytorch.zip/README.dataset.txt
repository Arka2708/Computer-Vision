# Sign Language > 2024-05-15 9:48am
https://universe.roboflow.com/forfun-cyh93/sign-language-fr0hf

Provided by a Roboflow user
License: CC BY 4.0

